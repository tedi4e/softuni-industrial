<?php

return array(
	'dependencies' => array(
		'wp-i18n',
	),
	'version' => WPCF7_VERSION,
);
