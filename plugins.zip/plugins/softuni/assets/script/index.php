<?php 
// Silence is golden.
