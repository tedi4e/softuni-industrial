<?php 
/*
 * Plugin Name: SoftUni
 * Version: 0.1
 * Description: This is my first plugin for the course.
 */

/*
* Custom Post Type
* Custom Taxonomy
* Create a helper funcions
* Update our plugin structure
* Theme vs Plugin funcionality
* Deploy the code to GitHub
* i18n functions
*/


if ( ! defined( 'SOFTUNI_PLUGIN_VERSION' ) ) {
    define( 'SOFTUNI_PLUGIN_VERSION', '0.1' );
}

if ( ! defined( 'SOFTUNI_PLUGIN_ASSETS_URL') ) {
    define( 'SOFTUNI_PLUGIN_ASSETS_URL', plugin_dir_url(__FILE__) . '/assets' );
}  


require 'includes/cpt-projects.php';
require 'includes/cpt-testimonial.php';