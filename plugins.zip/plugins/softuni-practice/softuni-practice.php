<?php

/**
 * Plugin Name: Softuni Practice
 * Author: Teodora Erdanovska
 * Author URI: https://erdanovska.com
 * Description: This is a playground plugin for the pragtice session.
 */

 /**
  * Cnhanging the title of a blog post
  *
  *@param [type] $title
  *@return void
  */
 