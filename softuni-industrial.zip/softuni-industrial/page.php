<?php get_header(); ?>
    
     <!-- Start section About -->
    <?php // if ( have_post() ): ?>

    <section class="section element-animate">
      <div class="container">
        <div class="row align-items-center mb-5">
          <div class="col-lg-7 order-md-2">
            <div class="scaling-image"><div class="frame"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/industrial_featured_img_1.jpg" alt="Free template by Free-Template.co" class="img-fluid"></div></div>
          </div>
          <div class="col-md-5 pr-md-5 mb-5">
            <div class="block-41">
              <h2 class="block-41-heading mb-5"><?php echo get_the_title(); ?></h2>
              <div class="block-41-text">
                    <?php the_content(); ?>
                
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </section>

    <?php // endif; ?>
    <!-- END section -->

<?php get_footer(); ?>


    