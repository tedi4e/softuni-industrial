SoftUni Industrial
This our GitHub repository for WordPress for developers course at Softuni.

We are using this static HTML template to convert it to a dynamic WordPress theme with the help of a few custom plugins