<?php get_header(); ?>

    <section class="section blog">
      <div class="container">
        <div class="row justify-content-center mb-5 element-animate">
          <div class="col-md-8 text-left">
            <h2 class=" heading mb-4"><?php echo get_the_archive_title(); ?></h2>
            <div>
                <?php echo get_the_author_meta('description'); ?>
            </div>
           </div>
        </div>

        <?php if ( have_posts() ) : ?>
        <div class="row">
        
          <div class="col-md-6">

          <?php while ( have_posts() ) : the_post(); ?>

           <div class="media mb-4-block element-animate">
            
            <?php if ( has_post_thumbnail() ) : ?>
               
              <section class="home-slider owl-carousel">
               <a href="#" class="mr-5"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/industrial_blog_1.jpg" alt="Free website template by Free-Template.co" class="img-fluid"></a>
              <?php  endif; ?>
              
              <div class="media-body">
              <span class="post-meta"><?php echo  get_the_date(); ?></span>
                <h3 class="mt-2 text-black"><a href="<?php echo get_the_permalink(); ?>"><?php the_title(); ?></a></h3>
                <p><?php the_excerpt(); ?></p>
                <p><a href="#" class="readmore">Read More <span class="ion-android-arrow-dropright-circle"></span></a></p>
              </div>
            </div>
            
          <?php endwhile; ?>  
          <?php 
          the_posts_pagination( array(
                  'mid_size'  => 2,
                  'prev_text' => __( 'Назад', 'textdomain' ),
                  'next_text' => __( 'Напред', 'textdomain' ),
          ) ); 
          ?>
          </div>
        </div>

        <?php else : ?>
          No post to be show
        <?php endif; ?>

      </div>
    </section>

<?php get_footer(); ?>