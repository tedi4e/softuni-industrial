<?php

add_theme_support( 'title-tag' );
add_theme_support( 'post-thumbnails' );

add_post_type_support( 'excerpt');

add_action( 'wp_enqueue_scripts', 'softuni_enqueue_assets' );
function softuni_enqueue_assets () {
    // wp_enqueue_style( 'softuni', get_stylesheet_directory_uri( ) . '/style.css');
    // wp_enqueue_style( 'stoftuni', get_stylesheet_uri( ) );

}


function softuni_display_latest_posts( $number_of_post = 3 ) {
    include 'latest-post.php';
}


function softuni_body_class( $classes) {
    $classes[] = 'softuni-test-class' ;

    return $classes;
}

add action( 'body_class' , 'softuni_body_class');




/**
 * This is the main function to register navigation menu
 */
function softuni_register_nav_menus() {
    register_nav_menus(
        array(
            'primary_menu'          => __( 'Primary Menu', 'textdomain' ),
            'primary_menu_mobile'   => __( 'Primary Menu Mobile', 'textdomain' ),
            'footer_menu_site_info' => __( 'Footer Menu Site Info', 'textdomain' ),
        )
    );

    register_nav_menu( 'primary', 'This is our main mavigation menu' );
}


    add_action( 'after_setup_theme', 'softuni_register_nav_menus', 0 );

    