<?php
/**
 * Template Name: Homepage
 */
?>

<?php get_header(); ?>

          <div class="collapse navbar-collapse" id="navbarsExample05">
            <ul class="navbar-nav pl-md-5 ml-auto">
              <li class="nav-item">
                <a class="nav-link active" href="index.html">Home</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="about.html">About</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="projects.html">Projects</a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="services.html" id="dropdown04" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Services</a>
                <div class="dropdown-menu" aria-labelledby="dropdown04">
                  <a class="dropdown-item" href="services.html">Architectural Design</a>
                  <a class="dropdown-item" href="services.html">Interior</a>
                  <a class="dropdown-item" href="services.html">Building</a>
                </div>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="blog.html">Blog</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="contact.html">Contact</a>
              </li>
            </ul>

            <div class="navbar-nav ml-auto">
              <form method="post" class="search-form">
                <span class="icon ion ion-search"></span>
                <input type="text" class="form-control" placeholder="Search...">
              </form>
            </div>
            
          </div>
        </div>
      </nav>
    </header>
    <!-- END header -->

  
    <section class="section bg-light">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-4 element-animate ">
            <div class="media block-6 d-block text-center">
              <div class="icon mb-3"><span class="ion-android-notifications text-primary"></span></div>
              <div class="media-body">
                <h3 class="heading">Modern Design</h3>
                <p>Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic.</p>
              </div>
            </div>  

          </div>
          <div class="col-md-6 col-lg-4 element-animate ">
            <div class="media block-6 d-block text-center">
              <div class="icon mb-3"><span class="ion-heart text-primary"></span></div>
              <div class="media-body">
                <h3 class="heading">Built With Passion</h3>
                <p>Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic.</p>
              </div>
            </div> 

          </div>
          <div class="col-md-6 col-lg-4 element-animate ">
            <div class="media block-6 d-block text-center">
              <div class="icon mb-3"><span class="ion-flash text-primary"></span></div>
              <div class="media-body">
                <h3 class="heading">Fast Loading</h3>
                <p>Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic.</p>
              </div>
            </div> 

          </div>
        </div>
      </div>
    </section>
    <!-- END section -->
    <section class="section element-animate">
      <div class="container">
        <div class="row align-items-center mb-5">
          <div class="col-lg-7 order-md-2">
            <div class="scaling-image"><div class="frame"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/industrial_featured_img_1.jpg" alt="Free template by Free-Template.co" class="img-fluid"></div></div>
          </div>
          <div class="col-md-5 pr-md-5 mb-5">
            <div class="block-41">
              <h2 class="block-41-heading mb-5">Let's Build Together</h2>
              <div class="block-41-text">
                <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
                <p><a href="#" class="readmore">Read More <span class="ion-android-arrow-dropright-circle"></span></a></p>
              </div>
            </div>
          </div>
          
        </div>
      </div>
    </section>

    

    <section class="section border-t pb-0">
      <div class="container">
        <div class="row justify-content-center mb-5 element-animate">
          <div class="col-md-8 text-center">
            <h2 class=" heading mb-4">Projects</h2>
            <p class="mb-5 lead">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
          </div>
        </div>
      </div>
      <div class="container-fluid">
        <div class="row no-gutters">
          <div class="col-md-4 element-animate">
            <a href="project-single.html" class="link-thumbnail">
              <h3>Ducting Design in Colorado</h3>
              <span class="ion-plus icon"></span>
              <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/industrial_img_1.jpg" alt="Free template by Free-Template.co" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 element-animate">
            <a href="project-single.html" class="link-thumbnail">
              <h3>Tanks Project In California</h3>
              <span class="ion-plus icon"></span>
              <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/industrial_img_2.jpg" alt="Free template by Free-Template.co" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 element-animate">
            <a href="project-single.html" class="link-thumbnail">
              <h3>Structural Design in New York</h3>
              <span class="ion-plus icon"></span>
              <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/industrial_img_3.jpg" alt="Free template by Free-Template.co" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 element-animate">
            <a href="project-single.html" class="link-thumbnail">
              <h3>Stacks Design</h3>
              <span class="ion-plus icon"></span>
              <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/industrial_img_4.jpg" alt="Free template by Free-Template.co" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 element-animate">
            <a href="project-single.html" class="link-thumbnail">
              <h3>Intercate Custom</h3>
              <span class="ion-plus icon"></span>
              <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/industrial_img_5.jpg" alt="Free template by Free-Template.co" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 element-animate">
            <a href="project-single.html" class="link-thumbnail">
              <h3>Banker Design</h3>
              <span class="ion-plus icon"></span>
              <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/industrial_img_6.jpg" alt="Free template by Free-Template.co" class="img-fluid">
            </a>
          </div>
        </div>
        
      </div>
    </section>
    <!-- END section -->

    <section class="section bg-light block-11">
      <div class="container"> 
        <div class="row justify-content-center mb-5">
          <div class="col-md-8 text-center">
            <h2 class=" heading mb-4">Testimonial</h2>
          </div>
        </div>
        <div class="nonloop-block-11 owl-carousel">
          <div class="item">
            <div class="block-33 h-100">
                <div class="vcard d-flex mb-3">
                  <div class="image align-self-center"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/person_3.jpg" alt="Person here"></div>
                  <div class="name-text align-self-center">
                    <h2 class="heading">John Smith</h2>
                    <span class="meta">Free-Template.co Client</span>
                  </div>
                </div>
                <div class="text">
                  <blockquote>
                    <p>&rdquo; The Big Oxmox advised her not to do so, because there were thousands of bad Commas, wild Question Marks and devious Semikoli, but the Little Blind Text didn’t listen. She packed her seven versalia, put her initial into the belt and made herself on the way. &ldquo;</p>
                  </blockquote>
                </div>
              </div>
          </div>

          <div class="item">
            <div class="block-33 h-100">
                <div class="vcard d-flex mb-3">
                  <div class="image align-self-center"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/person_2.jpg" alt="Person here"></div>
                  <div class="name-text align-self-center">
                    <h2 class="heading">Joshua Darren</h2>
                    <span class="meta">Free-Template.co Client</span>
                  </div>
                </div>
                <div class="text">
                  <blockquote>
                    <p>&rdquo; Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar. &ldquo;</p>
                  </blockquote>
                </div>
              </div>
          </div>

          <div class="item">
            <div class="block-33 h-100">
                <div class="vcard d-flex mb-3">
                  <div class="image align-self-center"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/person_3.jpg" alt="Person here"></div>
                  <div class="name-text align-self-center">
                    <h2 class="heading">John Smith</h2>
                    <span class="meta">Free-Template.co Client</span>
                  </div>
                </div>
                <div class="text">
                  <blockquote>
                    <p>&rdquo; A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth. &ldquo;</p>
                  </blockquote>
                </div>
              </div>
          </div>

          <div class="item">
            <div class="block-33 h-100">
                <div class="vcard d-flex mb-3">
                  <div class="image align-self-center"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/person_3.jpg" alt="Person here"></div>
                  <div class="name-text align-self-center">
                    <h2 class="heading">John Smith</h2>
                    <span class="meta">Free-Template.co Client</span>
                  </div>
                </div>
                <div class="text">
                  <blockquote>
                    <p>&rdquo; Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. &ldquo;</p>
                  </blockquote>
                </div>
              </div>
          </div>
          
        </div>
      </div>
    </div>
    <!-- END .block-4 -->
    </section>

    <section class="section blog">
      <div class="container">

        <div class="row justify-content-center mb-5 element-animate">
          <div class="col-md-8 text-center">
            <h2 class=" heading mb-4">Blog Posts</h2>
            <p class="mb-5 lead">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
          </div>
        </div>

        <div class="row">
          <div class="col-md-6">

            <div class="media mb-4 d-md-flex d-block element-animate">
              <a href="#" class="mr-5"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/industrial_blog_1.jpg" alt="Free website template by Free-Template.co" class="img-fluid"></a>
              <div class="media-body">
                <span class="post-meta">Feb 26th, 2018</span>
                <h3 class="mt-2 text-black"><a href="#">How to handle any intercate custom design</a></h3>
                <p>Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>
                <p><a href="#" class="readmore">Read More <span class="ion-android-arrow-dropright-circle"></span></a></p>
              </div>
            </div>



          </div>
          <div class="col-md-6">
            <div class="media mb-4 d-md-flex d-block element-animate">
              <a href="#" class="mr-5"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/industrial_blog_2.jpg" alt="Free website template by Free-Template.co" class="img-fluid"></a>
              <div class="media-body">
                <span class="post-meta">Feb 26th, 2018</span>
                <h3 class="mt-2 text-black"><a href="#">How to handle any intercate custom design</a></h3>
                <p><a href="#" class="readmore">Read More <span class="ion-android-arrow-dropright-circle"></span></a></p>
              </div>
            </div>

            <div class="media mb-4 d-md-flex d-block element-animate">
              <a href="#" class="mr-5"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/industrial_blog_3.jpg" alt="Free website template by Free-Template.co" class="img-fluid"></a>
              <div class="media-body">
                <span class="post-meta">Feb 26th, 2018</span>
                <h3 class="mt-2 text-black"><a href="#">How to handle any intercate custom design</a></h3>
                <p><a href="#" class="readmore">Read More <span class="ion-android-arrow-dropright-circle"></span></a></p>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
    <section class="section bg-primary">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-8">
            <h2 class="text-white mb-0">Get Started With Industrial Free Template</h2>
            <p class="text-white lead">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. .</p>
          </div>
          <div class="col-lg-4 text-lg-right">
            <a href="https://free-template.co/" class="btn btn-outline-white px-4 py-3">Download This Template</a>
          </div>
        </div>
      </div>
    </section>
    <footer class="site-footer" role="contentinfo">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-4 mb-5">
            <h3>About The Industrial</h3>
            <p class="mb-5">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. .</p>
            <ul class="list-unstyled footer-link d-flex footer-social">
              <li><a href="#" class="p-2"><span class="fa fa-twitter"></span></a></li>
              <li><a href="#" class="p-2"><span class="fa fa-facebook"></span></a></li>
              <li><a href="#" class="p-2"><span class="fa fa-linkedin"></span></a></li>
              <li><a href="#" class="p-2"><span class="fa fa-instagram"></span></a></li>
            </ul>

          </div>
          <div class="col-md-5 mb-5 pl-md-5">
            <h3>Contact Info</h3>
            <ul class="list-unstyled footer-link">
              <li class="d-block">
                <span class="d-block">Address:</span>
                <span >34 Street Name, City Name Here, United States</span></li>
              <li class="d-block"><span class="d-block">Telephone:</span><span >+1 242 4942 290</span></li>
              <li class="d-block"><span class="d-block">Email:</span><span >info@yourdomain.com</span></li>
            </ul>
          </div>
          <div class="col-md-3 mb-5">
            <h3>Quick Links</h3>
            <ul class="list-unstyled footer-link">
              <li><a href="#">About</a></li>
              <li><a href="#">Terms of Use</a></li>
              <li><a href="#">Disclaimers</a></li>
              <li><a href="#">Contact</a></li>
            </ul>
          </div>
          <div class="col-md-3">
          
          </div>
        </div>
        <div class="row">
          <div class="col-12 text-md-center text-left">
             <p class="copyright">
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart text-danger" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank" >Colorlib</a>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
          </div>
        </div>
      </div>
    </footer>
    <!-- END footer -->

    <!-- loader -->
    <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#f4b214"/></svg></div>

    <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/jquery-3.2.1.min.js"></script>
    <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/popper.min.js"></script>
    <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/bootstrap.min.js"></script>
    <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/owl.carousel.min.js"></script>
    <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/jquery.waypoints.min.js"></script>
    <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/jquery.fancybox.min.js"></script>
    <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/main.js"></script>

    <script src="<?php echo get_stylesheet_directory_uri(); ?>/js/main.js"></script>
    
  </body>
</html>








